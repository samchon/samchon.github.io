#include <samchon/protocol/SharedEntityArray.hpp>

using namespace samchon;
using namespace samchon::protocol;

SharedEntityArray::SharedEntityArray()
	: super()
{
}