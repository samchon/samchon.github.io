#include <samchon/protocol/IProtocol.hpp>
using namespace samchon::protocol;

IProtocol::IProtocol() {}