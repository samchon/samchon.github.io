#include <samchon/protocol/EntityArray.hpp>
#include <samchon/protocol/SharedEntityArray.hpp>
// #include <samchon/protocol/UniqueEntityArray.hpp>

#include <samchon/protocol/EntityList.hpp>
#include <samchon/protocol/SharedEntityList.hpp>
// #include <samchon/protocol/UniqueEntityList.hpp>