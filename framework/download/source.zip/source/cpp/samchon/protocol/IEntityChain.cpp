#include <samchon/protocol/IEntityChain.hpp>
#	include <samchon/protocol/IEntityChain.hpp>

using namespace samchon::protocol;

IEntityChain::IEntityChain(Entity *entity)
{
	this->entity = entity;
}