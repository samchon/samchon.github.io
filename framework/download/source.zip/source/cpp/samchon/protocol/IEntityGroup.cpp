#include <samchon/protocol/IEntityGroup.hpp>

using namespace samchon::protocol;

IEntityGroup::IEntityGroup()
{
}