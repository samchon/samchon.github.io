#include <samchon/namtree/NTEntityGroup.hpp>

using namespace std;
using namespace samchon::namtree;

NTEntityGroup::NTEntityGroup()
{
}