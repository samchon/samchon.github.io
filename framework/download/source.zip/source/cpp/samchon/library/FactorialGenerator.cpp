#include <samchon/library/FactorialGenerator.hpp>

using namespace std;
using namespace samchon::library;

FactorialGenerator::FactorialGenerator(size_t n)
	: super(n, n)
{
}