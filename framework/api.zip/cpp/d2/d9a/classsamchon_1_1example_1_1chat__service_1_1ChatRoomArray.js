var classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray =
[
    [ "ChatRoomArray", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#a7ce48784108ab3abdcaedbeae0bf5f8f", null ],
    [ "CHILD_TAG", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#a344b76fa771a6432785ec6d340f69384", null ],
    [ "notify", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#a5ea05f0b01dc3ef7cf34d08602e09eb5", null ],
    [ "toXML", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#ae5ee1a42571f3ef124bc8c0d2cec672e", null ],
    [ "toInvoke", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#a227fb2ea6055b9bc7824b29233bc929b", null ],
    [ "server", "d2/d9a/classsamchon_1_1example_1_1chat__service_1_1ChatRoomArray.html#ab31bfcbd45bda14a21f00a56b81c8cdd", null ]
];