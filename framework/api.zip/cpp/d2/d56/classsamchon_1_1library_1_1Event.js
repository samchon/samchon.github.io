var classsamchon_1_1library_1_1Event =
[
    [ "Event", "d2/d56/classsamchon_1_1library_1_1Event.html#a2b77e0cf6800331b5ca1fa03e975e7d1", null ],
    [ "getSource", "d2/d56/classsamchon_1_1library_1_1Event.html#a68a128c093ba5ad3c415fc64d1224ad8", null ],
    [ "getType", "d2/d56/classsamchon_1_1library_1_1Event.html#a304d366987980085a052d017e30342b7", null ],
    [ "source", "d2/d56/classsamchon_1_1library_1_1Event.html#a4a1f085faecf6b69fe99a28d1fd9368d", null ],
    [ "type", "d2/d56/classsamchon_1_1library_1_1Event.html#a9d320b88ed35b413642980310ed9332b", null ]
];