var classsamchon_1_1protocol_1_1SystemRole =
[
    [ "SystemRole", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#ace68aa13ebf85e640daf3be2d2a6ea5b", null ],
    [ "construct", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#ad99a65c1c4669d594415a5bad27de28f", null ],
    [ "key", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#a10917e010f3df02b928a4d46610c5317", null ],
    [ "hasListener", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#a068dd076d6cafc1df85df59b62c2f6d1", null ],
    [ "TAG", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#ac9d40f0944acf75ce2261946dfcf57f9", null ],
    [ "toXML", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#a973f5017e97734b3b2655a799cd5ba26", null ],
    [ "name", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#a368201f9039b981a9fb3989884560d94", null ],
    [ "listeners", "d5/de8/classsamchon_1_1protocol_1_1SystemRole.html#aca710ebcaef132caaea3e7185e05f007", null ]
];