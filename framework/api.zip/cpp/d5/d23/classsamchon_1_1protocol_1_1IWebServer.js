var classsamchon_1_1protocol_1_1IWebServer =
[
    [ "IWebServer", "d5/d23/classsamchon_1_1protocol_1_1IWebServer.html#a8f64bf8d37a6f07dc099fa4b684e3aad", null ],
    [ "open", "d5/d23/classsamchon_1_1protocol_1_1IWebServer.html#aafea25649b99b957edce59d5017d7a8b", null ]
];