var classsamchon_1_1example_1_1chat__service_1_1ChatClient =
[
    [ "ChatClient", "d4/dba/classsamchon_1_1example_1_1chat__service_1_1ChatClient.html#ada8dd69b31d724a312112bc1ad99c122", null ],
    [ "createService", "d4/dba/classsamchon_1_1example_1_1chat__service_1_1ChatClient.html#a83df92a083dfad28c186693cb2d6f4e4", null ]
];