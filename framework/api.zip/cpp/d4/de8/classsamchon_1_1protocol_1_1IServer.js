var classsamchon_1_1protocol_1_1IServer =
[
    [ "IServer", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#a97584378735a1a0bee7ecfec6c027573", null ],
    [ "MY_IP", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#aef2532b3dd604bafbd58fc09a35ff3ac", null ],
    [ "PORT", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#a1bee88a3b4508af65b7e9796157562db", null ],
    [ "open", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#ac902fd72d7fee9bcd618819393bf4ab0", null ],
    [ "close", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#a6ecfd4d9e3117e6487f1afca209e8470", null ],
    [ "addClient", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#ab8b799b5c1e768fd4162771b797a00bd", null ],
    [ "acceptor", "d4/de8/classsamchon_1_1protocol_1_1IServer.html#aeaf892467eb5a15b1869a121138f60dc", null ]
];