var classsamchon_1_1protocol_1_1ExternalSystemRole =
[
    [ "ExternalSystemRole", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a2958e1a294811e1144235b8c0badd8cd", null ],
    [ "construct", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a171773044f5777e2d32e6d65c141c13e", null ],
    [ "getSystem", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a5bb80371e68127ea60fc8672c39fb336", null ],
    [ "key", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a34629add016e5b22a7edad4d31b2d946", null ],
    [ "hasSendListener", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#aac8efbf32aa7819161412997b1365608", null ],
    [ "hasReplyListener", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a30b95d488046d4f2f6f32e4a172520be", null ],
    [ "sendData", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a0296a7905eda64ed8831c3ab0f242455", null ],
    [ "TAG", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a91b061d835613278049b4998bc408261", null ],
    [ "toXML", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a7708b96d6268818e36d1ea0fed321520", null ],
    [ "system", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a8f68fa6bbfec7ba7689300476179ae6f", null ],
    [ "name", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a5cf1a7e3efb0658cad2424d396cb2175", null ],
    [ "replyListeners", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a662d23eb44cf17a9e2fe7783885c269c", null ],
    [ "sendListeners", "d4/db7/classsamchon_1_1protocol_1_1ExternalSystemRole.html#a87f806ca0890a4bb41d0d7dfa7a61c7f", null ]
];