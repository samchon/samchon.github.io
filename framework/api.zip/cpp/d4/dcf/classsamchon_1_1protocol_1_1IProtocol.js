var classsamchon_1_1protocol_1_1IProtocol =
[
    [ "IProtocol", "d4/dcf/classsamchon_1_1protocol_1_1IProtocol.html#a5d0bea0ab92929e492b7bf5a250346ea", null ],
    [ "replyData", "d4/dcf/classsamchon_1_1protocol_1_1IProtocol.html#a6760c7213201af3ad99e48808d46ccfb", null ],
    [ "sendData", "d4/dcf/classsamchon_1_1protocol_1_1IProtocol.html#a522a5cfdb02c515d65e7caa1b90f323f", null ]
];