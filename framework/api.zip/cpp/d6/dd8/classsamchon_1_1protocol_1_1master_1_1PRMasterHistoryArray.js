var classsamchon_1_1protocol_1_1master_1_1PRMasterHistoryArray =
[
    [ "PRMasterHistoryArray", "d6/dd8/classsamchon_1_1protocol_1_1master_1_1PRMasterHistoryArray.html#a355f65bdffae1ebc3d519bc655be64c7", null ],
    [ "master", "d6/dd8/classsamchon_1_1protocol_1_1master_1_1PRMasterHistoryArray.html#a75f698058daa7453161cba137d8ef4f1", null ]
];