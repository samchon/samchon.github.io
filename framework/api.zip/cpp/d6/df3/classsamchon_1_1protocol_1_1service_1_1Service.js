var classsamchon_1_1protocol_1_1service_1_1Service =
[
    [ "Service", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#a5b8b2cb48cf38c22da5e9d8adcca807d", null ],
    [ "REQUIRE_AUTHORITY", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#aad91285df95f15c577b8beca3a2da319", null ],
    [ "getClient", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#a54ae4aaec78d376d378f5bfb4056b2b6", null ],
    [ "sendData", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#abf3980854281a448cbf326f90eb7a0f6", null ],
    [ "client", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#abdf6203c973cc1bc797561b73fa87cc4", null ],
    [ "name", "d6/df3/classsamchon_1_1protocol_1_1service_1_1Service.html#a3e8f8aa70b806d7cc74246f89367bf4b", null ]
];