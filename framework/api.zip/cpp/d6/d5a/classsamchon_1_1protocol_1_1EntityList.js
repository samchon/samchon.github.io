var classsamchon_1_1protocol_1_1EntityList =
[
    [ "EntityList", "d6/d5a/classsamchon_1_1protocol_1_1EntityList.html#a2f92a7ff92c67024277bfaf6c4410a9b", null ],
    [ "construct", "d6/d5a/classsamchon_1_1protocol_1_1EntityList.html#a88e7e4f721f9d4c9244998751adcac7d", null ],
    [ "toXML", "d6/d5a/classsamchon_1_1protocol_1_1EntityList.html#a24cb6805565abcd6241d279366bbefb9", null ]
];