var classsamchon_1_1protocol_1_1master_1_1ParallelSystem =
[
    [ "ParallelSystem", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a4487141cf92fe0ea81feb93bf4c82ff0", null ],
    [ "construct", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#abcd5cabda3dece97aecc41b681975a2c", null ],
    [ "createChild", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a5ec1ec3c59f7322781010f3b85e8af62", null ],
    [ "_replyData", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a609f8b46a2f472a0fba8af8e3bdb8bc7", null ],
    [ "sendPieceData", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#aea9eeae174e52b84597bafdf344b668d", null ],
    [ "toXML", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a6666927b280b7b3a55f394ce2bc845fb", null ],
    [ "systemArray", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#af78eec9865bc9be7a3c137cc72cfd02b", null ],
    [ "historyArray", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a749c52d280cc51abd6a09c957a9a621a", null ],
    [ "progressArray", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#a80ae82769aad1893e5c3274898b91eb7", null ],
    [ "performance", "d9/d6b/classsamchon_1_1protocol_1_1master_1_1ParallelSystem.html#ad02a6b0adc9716e170d5f65010927bcb", null ]
];