var classsamchon_1_1example_1_1interaction_1_1Slave =
[
    [ "Slave", "d9/d61/classsamchon_1_1example_1_1interaction_1_1Slave.html#a3de2984639bba9c2d3e39d30e16f0f4f", null ],
    [ "optimize", "d9/d61/classsamchon_1_1example_1_1interaction_1_1Slave.html#a8252af9e74b59dbfbd9f21b5a61a7777", null ],
    [ "sendOptimization", "d9/d61/classsamchon_1_1example_1_1interaction_1_1Slave.html#ab8988c38c763eb87dc0330b95292a46a", null ]
];