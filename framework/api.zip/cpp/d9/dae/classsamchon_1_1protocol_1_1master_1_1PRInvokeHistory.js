var classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory =
[
    [ "PRInvokeHistory", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a5c6568c1d67bbed925025912c2ae220c", null ],
    [ "PRInvokeHistory", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#ac0906aa635a172e1be0353c53acd7586", null ],
    [ "construct", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a830b3c0848a4455894fc5aa5f5f838b4", null ],
    [ "notifyEnd", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a70e52da1a8d664b60a8ceac6a947950a", null ],
    [ "getIndex", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a4a2fc0234487f9778cf60f783d381ff4", null ],
    [ "getSize", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#af382c404ad2cae5998f2c46eabf7051b", null ],
    [ "calcAverageElapsedTime", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a2763eecaaa3fa00a205f66b583b4c1c4", null ],
    [ "toXML", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#ace6f222c75767b3f53efcd1f173f1ac0", null ],
    [ "masterHistory", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a833d1f5dee312394cc18b0665f884e79", null ],
    [ "system", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#adac5673f66d2a68fe13aa5168b8b4a64", null ],
    [ "index", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a257d862af7db50a63a72307ddd68094e", null ],
    [ "size", "d9/dae/classsamchon_1_1protocol_1_1master_1_1PRInvokeHistory.html#a299e2d680b3521ae1f64a31710c8793e", null ]
];