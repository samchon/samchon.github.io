var classsamchon_1_1protocol_1_1IEntityGroup =
[
    [ "IEntityGroup", "d9/d4c/classsamchon_1_1protocol_1_1IEntityGroup.html#a4bba309d87fa607c1f532cf3e6f7a066", null ],
    [ "CHILD_TAG", "d9/d4c/classsamchon_1_1protocol_1_1IEntityGroup.html#ae0a5bb34fa6a29cf1103fc67e2d72662", null ]
];