var classsamchon_1_1protocol_1_1IEntityChain =
[
    [ "IEntityChain", "d3/d66/classsamchon_1_1protocol_1_1IEntityChain.html#adf162f4e6555249b0c38fa0bb06f120a", null ],
    [ "entity", "d3/d66/classsamchon_1_1protocol_1_1IEntityChain.html#ad73dd2fdb4016b2788a77c567866166c", null ]
];