var structsamchon_1_1library_1_1GAParameters =
[
    [ "generation", "d3/dcb/structsamchon_1_1library_1_1GAParameters.html#a665f058da9a453d70188d12d5373e94e", null ],
    [ "population", "d3/dcb/structsamchon_1_1library_1_1GAParameters.html#a1befe3979a7049f0e9b8e71320d92ee5", null ],
    [ "tournament", "d3/dcb/structsamchon_1_1library_1_1GAParameters.html#aa27ea978793660e6d72fe501887bf6e4", null ],
    [ "mutationRate", "d3/dcb/structsamchon_1_1library_1_1GAParameters.html#a6754f86d21a24e9e6d8e67421acf00bd", null ]
];