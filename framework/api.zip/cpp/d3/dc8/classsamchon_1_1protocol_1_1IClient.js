var classsamchon_1_1protocol_1_1IClient =
[
    [ "IClient", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#a31410c2a45ff2c983db888ddbefcfa39", null ],
    [ "BUFFER_SIZE", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#aeb5632980254d2e48c5522ecba26d338", null ],
    [ "listen", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#a2c36bef1ddcc101dd1e1364ab22f4ee3", null ],
    [ "sendData", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#a44d95d1c5fb75aed2f41a5b4cca0df9e", null ],
    [ "_replyData", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#a52b60a465279200efb4a77ec9becb43f", null ],
    [ "socket", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#af61f5e26383c9eba182d578f1572e89c", null ],
    [ "sendMtx", "d3/dc8/classsamchon_1_1protocol_1_1IClient.html#aed772851e668352566c18806fc6456f4", null ]
];