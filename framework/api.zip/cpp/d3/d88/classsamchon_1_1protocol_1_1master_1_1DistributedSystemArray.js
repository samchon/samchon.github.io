var classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray =
[
    [ "DistributedSystemArray", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a3757cd209bd97042bb4f7dcd5b3d646f", null ],
    [ "construct", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#ad57f9f69800c1af5f820f500ff0aab4b", null ],
    [ "createRole", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#aff3795e5196392d0e6e43a33757b18f1", null ],
    [ "start", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a607927b91adf09f44214fdb3b2bf161d", null ],
    [ "allocateRoles", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a86bdfb5d221d7d30b668f50a8b9313db", null ],
    [ "hasRole", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a21b3da820d19093322b9532ed6cb38b1", null ],
    [ "getRole", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a076278abec211fb27dfb3a6abffeac27", null ],
    [ "toXML", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a70f6678d5e4e2e762e9ee6799b29db65", null ],
    [ "roleDictionary", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#ad941197cb772b0d2fb9e3a0ae0300456", null ],
    [ "gaParameters", "d3/d88/classsamchon_1_1protocol_1_1master_1_1DistributedSystemArray.html#a842ed640022fa5f511b164bf25aead4b", null ]
];