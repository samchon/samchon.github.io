var classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole =
[
    [ "DistributedSystemRole", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#afcbd6f1ce19b65183405b1fa0168d287", null ],
    [ "construct", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a9c2314e3a3b694c905c6b85be5911737", null ],
    [ "getSystem", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a97643bdde173de7627b0a60f47513426", null ],
    [ "getPerformance", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a2bc2c6cdab529d48c9dc2bbe789f41fb", null ],
    [ "getAllocationHistoryList", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a7456f69837baa416180e506e7c354031", null ],
    [ "getInvokeHistoryArray", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#ae2a841e897d2d707104cd94a30a12f6b", null ],
    [ "sendData", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a6deaee11868f905d02548bdca9b910c6", null ],
    [ "toXML", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#ad9cc5c37f994af9619ac49e5a3223ba8", null ],
    [ "allocatedSystems", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a6ecf204e10554633bdf0713ff4d869ec", null ],
    [ "performance", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#aa2077efeea63b5386dd64ac50b1a870c", null ],
    [ "allocationHistoryList", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#ae33a64ac389443b6f2b0109c0b348fa2", null ],
    [ "invokeHistoryArray", "d1/d16/classsamchon_1_1protocol_1_1master_1_1DistributedSystemRole.html#a3e208a8cd783e3a88d73f652aa825eb0", null ]
];