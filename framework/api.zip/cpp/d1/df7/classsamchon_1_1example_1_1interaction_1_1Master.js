var classsamchon_1_1example_1_1interaction_1_1Master =
[
    [ "Master", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a0ac34fa7e8fb6a3470aeab87adc349de", null ],
    [ "start", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a518a57d166f66c951cc12f74675a294e", null ],
    [ "createChild", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a51c850b366ce28b75f645f3301b2e112", null ],
    [ "addClient", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a02f96b51763dc831072543b83dfb8ad3", null ],
    [ "optimize", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a8091cf20f91348bb197f99d566e3f2ea", null ],
    [ "replyOptimization", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a9ef7de9ff0a34402763e1b258c09a396", null ],
    [ "chiefDriver", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a9c7f969dc985e33bfe75c4a8b3954503", null ],
    [ "mtx", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a1835f6cb9b8a1ff59e98735c0df7c18b", null ],
    [ "optimized", "d1/df7/classsamchon_1_1example_1_1interaction_1_1Master.html#a8b9879449faf2cdc2256d897c9f15d78", null ]
];