var classsamchon_1_1protocol_1_1slave_1_1SlaveSystem =
[
    [ "SlaveSystem", "d1/d4a/classsamchon_1_1protocol_1_1slave_1_1SlaveSystem.html#a69175236994f597a31377ba0f98593e6", null ],
    [ "_replyData", "d1/d4a/classsamchon_1_1protocol_1_1slave_1_1SlaveSystem.html#a6b97fafd0aa6e09fbe44b1a7b1c64484", null ]
];