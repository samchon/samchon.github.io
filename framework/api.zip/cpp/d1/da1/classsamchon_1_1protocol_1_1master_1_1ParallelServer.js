var classsamchon_1_1protocol_1_1master_1_1ParallelServer =
[
    [ "ParallelServer", "d1/da1/classsamchon_1_1protocol_1_1master_1_1ParallelServer.html#a7d6720959068d0a5639539b24d9e2474", null ],
    [ "construct", "d1/da1/classsamchon_1_1protocol_1_1master_1_1ParallelServer.html#ad948277651e9a18ccb2d4c4db9b48aa9", null ],
    [ "toXML", "d1/da1/classsamchon_1_1protocol_1_1master_1_1ParallelServer.html#a65fc91acb6029cd484e7e60837434b21", null ]
];