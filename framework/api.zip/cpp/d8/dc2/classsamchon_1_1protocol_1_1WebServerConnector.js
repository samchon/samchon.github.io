var classsamchon_1_1protocol_1_1WebServerConnector =
[
    [ "WebServerConnector", "d8/dc2/classsamchon_1_1protocol_1_1WebServerConnector.html#af263191bb8e93773be69582f02272bfa", null ],
    [ "connect", "d8/dc2/classsamchon_1_1protocol_1_1WebServerConnector.html#af967bda21e868502920f10cf9c5d13a6", null ]
];