var classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray =
[
    [ "ParallelSystemArray", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a54bc9bac90d7b3e835e8571fbfff139f", null ],
    [ "sendSegmentData", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a2e1e3eb730d9f1000e0d12517386c8da", null ],
    [ "sendPieceData", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a9952e09a1875800e98a40f131b37e2b0", null ],
    [ "notifyEnd", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a0346d46f78a275e3fd88f5380859de24", null ],
    [ "uid", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a8296032786aed138dc86995e9bdc6fd8", null ],
    [ "historyArray", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#a32313dd40502dab9912569868b734879", null ],
    [ "progressArray", "d8/d9c/classsamchon_1_1protocol_1_1master_1_1ParallelSystemArray.html#aaf85318c1117a92e925426d1d85b7143", null ]
];