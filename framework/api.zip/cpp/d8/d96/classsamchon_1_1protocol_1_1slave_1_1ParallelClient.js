var classsamchon_1_1protocol_1_1slave_1_1ParallelClient =
[
    [ "ParallelClient", "d8/d96/classsamchon_1_1protocol_1_1slave_1_1ParallelClient.html#a229b1bc86a544a6af2177d7e83d0db66", null ]
];