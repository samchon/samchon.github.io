var classsamchon_1_1protocol_1_1master_1_1DistributedServer =
[
    [ "DistributedServer", "d7/da8/classsamchon_1_1protocol_1_1master_1_1DistributedServer.html#af7af66e277f0f5da924547c2c4ea1888", null ],
    [ "construct", "d7/da8/classsamchon_1_1protocol_1_1master_1_1DistributedServer.html#aa155782153f298f7a09856427808d885", null ],
    [ "toXML", "d7/da8/classsamchon_1_1protocol_1_1master_1_1DistributedServer.html#a72b41e7cebf17752ecd753f3dfbb9ed9", null ]
];