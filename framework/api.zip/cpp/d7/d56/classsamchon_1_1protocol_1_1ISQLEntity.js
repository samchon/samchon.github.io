var classsamchon_1_1protocol_1_1ISQLEntity =
[
    [ "ISQLEntity", "d7/d56/classsamchon_1_1protocol_1_1ISQLEntity.html#ac6cb60454bc5e3de8f266b65fc19df72", null ],
    [ "load", "d7/d56/classsamchon_1_1protocol_1_1ISQLEntity.html#af6a9f8a80a5617bdf48e22af748224a9", null ],
    [ "archive", "d7/d56/classsamchon_1_1protocol_1_1ISQLEntity.html#a2b369863d18d049d7ee8b357938fdd91", null ],
    [ "toSQL", "d7/d56/classsamchon_1_1protocol_1_1ISQLEntity.html#ac4e892c7918f2e0c0082c6eecf91418c", null ]
];