var classsamchon_1_1library_1_1FTTextFile =
[
    [ "FTTextFile", "d7/d24/classsamchon_1_1library_1_1FTTextFile.html#a82f6419a03170ac96fea8eb08171798d", null ],
    [ "getData", "d7/d24/classsamchon_1_1library_1_1FTTextFile.html#a4acab25c0c9e54b7e393317dba7fd4de", null ],
    [ "data", "d7/d24/classsamchon_1_1library_1_1FTTextFile.html#a86f1bbeb6a338abd8d970815944b4949", null ]
];