var classsamchon_1_1example_1_1chat__service_1_1ChatRoom =
[
    [ "ChatRoom", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#afee15cc0f57a2d5a8fa384b55e1b49a9", null ],
    [ "TAG", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a542aef2726aa03b04331cf8c10fbb9fb", null ],
    [ "registerClient", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a829e10918ec29dc094346a1a542dc14c", null ],
    [ "eraseClient", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a32d8071c94df4eba9befbbd65c08349a", null ],
    [ "toXML", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a9696ef4e9ea5022fb04d16e35c0fd63a", null ],
    [ "roomArray", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a1daa643dd648234779a371851b0f00a3", null ],
    [ "name", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#ae2502e90581d1dff6a06ee63b38b3ac5", null ],
    [ "host", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#a03aefd9502948ba54f42d0b5ce4e7ba7", null ],
    [ "participants", "d7/d41/classsamchon_1_1example_1_1chat__service_1_1ChatRoom.html#ab94e5022f011a27dc32e12ae83c6d0a1", null ]
];