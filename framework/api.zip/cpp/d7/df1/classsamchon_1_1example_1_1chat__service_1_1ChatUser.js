var classsamchon_1_1example_1_1chat__service_1_1ChatUser =
[
    [ "ChatUser", "d7/df1/classsamchon_1_1example_1_1chat__service_1_1ChatUser.html#ab561d0b9217784d387930e181cba50e5", null ],
    [ "createClient", "d7/df1/classsamchon_1_1example_1_1chat__service_1_1ChatUser.html#a8dfea05bbb10e6951858e10089383f37", null ]
];