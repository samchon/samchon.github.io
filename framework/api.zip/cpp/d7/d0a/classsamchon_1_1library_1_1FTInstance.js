var classsamchon_1_1library_1_1FTInstance =
[
    [ "FTInstance", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#ae6695606b210a9949359772d4f83e3e9", null ],
    [ "TAG", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#ac4527c01f87b25e0821d69aa0dcbe88d", null ],
    [ "key", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#af93c6b7ed415f2f6469d691121ae9015", null ],
    [ "getUID", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#a34ad376e11e84ed49182f00e6b5d268b", null ],
    [ "getParent", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#acc86b21a931cabed47dc621bc90bed47", null ],
    [ "getName", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#a2246ad6e63375461b4c433d388574d8b", null ],
    [ "getComment", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#a27d56aa7acde46e1f11cb489b2d1f4c2", null ],
    [ "toXML", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#aed14b0a180aa13f4abb0948ad17372eb", null ],
    [ "parent", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#aef1070160f87c373466faaace185887d", null ],
    [ "uid", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#a2d8f2218b7ac7dad36a2057f50aa5a13", null ],
    [ "name", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#aff308be3106dda9409e70a8ba66ffd3c", null ],
    [ "comment", "d7/d0a/classsamchon_1_1library_1_1FTInstance.html#a91f4042853fee1e575dfa9f27e55a45c", null ]
];