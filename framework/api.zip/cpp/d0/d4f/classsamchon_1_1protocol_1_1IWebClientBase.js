var classsamchon_1_1protocol_1_1IWebClientBase =
[
    [ "IWebClientBase", "d0/d4f/classsamchon_1_1protocol_1_1IWebClientBase.html#a4f4c6dc26b7d2e355d648dab94ab96a3", null ],
    [ "listen", "d0/d4f/classsamchon_1_1protocol_1_1IWebClientBase.html#aa930d9ab8a18553f31dce1333e7ed712", null ],
    [ "sendData", "d0/d4f/classsamchon_1_1protocol_1_1IWebClientBase.html#a9a4902dd9d97f7486e1e1b36378491a7", null ]
];